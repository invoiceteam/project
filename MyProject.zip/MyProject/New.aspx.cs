﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class New : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindData();
        }
    }
    public void BindData()
    {
        SqlDataAdapter da;
        SqlConnection con;
        DataSet ds = new DataSet();


        if (ConfigurationManager.ConnectionStrings != null)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
          
            string cmd = "select * from project";

            SqlDataAdapter adpt = new SqlDataAdapter(cmd, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataBind();
            DropDownList1.DataTextField = "p_invoice";
            DropDownList1.DataValueField = "p_invoice";
            DropDownList1.DataBind();


        }
    }

 
    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    string id = TextBox1.Text;
    //    Sendemail(id);
    //    Response.Redirect("New.aspx");
    //}
    //public void Sendemail(string id)
    //{
    //    string ActivationUrl;
    //    try
    //    {
    //        MailMessage message = new MailMessage();
    //        message.From = new MailAddress("gnana.ameex@gmail.com", "prakash");
    //        message.To.Add(id);
    //        message.Subject = "Verification Email";
    //        ActivationUrl = Server.HtmlEncode("http://localhost:51244/MyProject/New.aspx");
    //        message.Body = "<a href='" + ActivationUrl + "'>Click Here to verify your acount</a>";
    //        message.IsBodyHtml = true;
    //        SmtpClient smtp = new SmtpClient();
    //        smtp.Host = "smtp.gmail.com";
    //        smtp.Port = 587;
    //        smtp.Credentials = new System.Net.NetworkCredential("ananth.ameex@gmail.com", "jeyalakshmi");
    //        smtp.EnableSsl = true;
    //        smtp.Send(message);
    //    }
    //    catch (Exception ex)
    //    {

    //    }
    //}

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        String qry = "select * from project  where p_types=" + DropDownList2.SelectedValue;
        SqlDataAdapter adpt = new SqlDataAdapter(qry, ConfigurationManager.ConnectionStrings["connect"].ConnectionString);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        DropDownList1.DataSource = dt;
        DropDownList1.DataBind();
        DropDownList1.DataTextField = "p_invoice";
        DropDownList1.DataValueField = "p_invoice";
        DropDownList1.DataBind();
        //if (DropDownList1.SelectedValue == "fixed")
        //{
        //    DropDownList2.Items.FindByValue("fixed").Enabled = true;
        //    DropDownList2.Items.FindByValue("fte").Enabled = false;
          
        //    start.Enabled = false;
        //    enddate.Enabled = false;

        //}
        //else if (DropDownList1.SelectedValue == "fte")
        //{
        //    DropDownList2.Items.FindByValue("fixed").Enabled = false;
        //    DropDownList2.Items.FindByValue("fte").Enabled = true;
            
        //    start.Enabled = false;
        //    enddate.Enabled = false;
        //    thours.Enabled = false;
        //}
    }


 
    //protected void btnsubmit_Click(object sender, EventArgs e)
    //{
    //    DateTime d1 = Convert.ToDateTime(start.Text.ToString());
    //    DateTime d2 = Convert.ToDateTime(enddate.Text.ToString());
    //    if (d1 > d2)
    //    {

    //        ClientScript.RegisterStartupScript(this.GetType(), "Alert", "alert('Start date must be less than end date')", true);
    //    }
    //}
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConn = new SqlConnection(@"Data Source=AMX-523-PC;Initial Catalog=Employee_details;Integrated Security=True");


        sqlConn.Open();
        string que = "INSERT INTO poc_details (poc1,email,invoice_mail,technology) values (@name,@email,@inmail,@tech)";
        SqlCommand myCommand = new SqlCommand(que, sqlConn);
        myCommand.Parameters.AddWithValue("@name", text1.Text);
        myCommand.Parameters.AddWithValue("@email", TextBox3.Text);
        myCommand.Parameters.AddWithValue("@inmail", TextBox1.Text);
        myCommand.Parameters.AddWithValue("@tech", dropdown.Text);
        myCommand.ExecuteNonQuery();
        string query = "INSERT INTO project (p_name,p_types,p_desc,p_invoice,f_assignee,s_date,e_date,t_hours,h_rate) values (@pname,@ptypes,@pdesc,@pinvoice,@assignee,@sdate,@edate,@thours,@hrate)";
        SqlCommand command = new SqlCommand(query, sqlConn);
        command.Parameters.AddWithValue("@pname", TextBox2.Text);
        command.Parameters.AddWithValue("@ptypes", DropDownList1.Text);
        command.Parameters.AddWithValue("@pdesc", desc.Text);
        command.Parameters.AddWithValue("@pinvoice", DropDownList2.Text);
        command.Parameters.AddWithValue("@assignee", DropDownList3.Text);
        command.Parameters.AddWithValue("@sdate", start.Text);
        command.Parameters.AddWithValue("@edate", enddate.Text);
        command.Parameters.AddWithValue("@thours", thours.Text);
        command.Parameters.AddWithValue("@hrate", rate.Text);
        //command.Parameters.AddWithValue("@sow", sowupload.Text);
        command.ExecuteNonQuery();
        sqlConn.Close();
       
    }
}