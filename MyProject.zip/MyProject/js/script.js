﻿$(document).ready(function ()
{
   
    var cnt = 1;
    $("#a1").click(function ()
    {
        $(".pick").prop("disabled",false);
    });
    $("#a2").click(function () {
        $(".pick1").prop("disabled", false);
    });
    $("#a3").click(function () {
        $(".thours").prop("disabled", false);
    });
    //$('.drop2').change(function () {
    //    var criteria = $(':selected', this).val();
    //    if (criteria == 0) {
    //        $('.pick1, .pick').prop("disabled", true);
    //    }
    //    else {
    //        $('.pick1, .pick').prop("disabled", false);
    //    }
    //});
    //$('#<%= DropDownList2.ClientID %>').change(function () {
    //    if (this.value == 0) {
    //        $('#<%= start.ClientID %>').css('display', 'block');
    //    }
    //    else {
    //        $('#<%= start.ClientID %>').css('display', 'none');
    //    }
    //});

    $("#anc_add").click(function () {
        if ($('#tbl1 tr').size() > 4) {
            if (cnt < 10)
            {
                if(cnt==1)
                    $('#tbl1 tr:eq(1)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name2" name="name3' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email2' + cnt + '"></td></tr>');
               else if (cnt == 2)
                   $('#tbl1 tr:eq(2)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name3" name="name3' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email3' + cnt + '"></td></tr>');
               else if (cnt == 3)
                   $('#tbl1 tr:eq(3)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name4" name="name4' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email4' + cnt + '"></td></tr>');
               else if (cnt == 4)
                   $('#tbl1 tr:eq(4)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name5" name="name5' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email5' + cnt + '"></td></tr>');
               else if (cnt == 5)
                   $('#tbl1 tr:eq(5)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name6" name="name6' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email6' + cnt + '"></td></tr>');
               else if (cnt == 6)
                   $('#tbl1 tr:eq(6)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name7" name="name7' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email7' + cnt + '"></td></tr>');
               else if (cnt == 7)
                   $('#tbl1 tr:eq(7)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name8" name="name8' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email8' + cnt + '"></td></tr>');
               else if (cnt == 8)
                   $('#tbl1 tr:eq(8)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td> <input type="text" placeholder="name9" name="name9' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email9' + cnt + '"></td></tr>');

                else 
                   $('#tbl1 tr:eq(9)').first().after('<tr><td>Point of Contact ' + cnt + '</td><td><input type="text" placeholder="name10" name="name10' + cnt + '"></td><td> <input type="text" placeholder="Email id" name="email10' + cnt + '"></td></tr>');
                cnt++;
                
            }

        }
    });

    $("#anc_rem").click(function () {
        if ($('#tbl1 tr').size() > 2) {
            if (cnt > 1)
            {
                if(cnt==10)
                    $('#tbl1 tr:eq(10)').remove();
                else if(cnt==9)
                    $('#tbl1 tr:eq(9)').remove();
                else if (cnt == 8)
                    $('#tbl1 tr:eq(8)').remove();
                else if (cnt == 7)
                    $('#tbl1 tr:eq(7)').remove();
                else if (cnt == 6)
                    $('#tbl1 tr:eq(6)').remove();
                else if (cnt == 5)
                    $('#tbl1 tr:eq(5)').remove();
                else if (cnt == 4)
                    $('#tbl1 tr:eq(4)').remove();
                else if (cnt == 3)
                    $('#tbl1 tr:eq(3)').remove();
                else if (cnt == 2)
                    $('#tbl1 tr:eq(2)').remove();
                else
                    $('#tbl1 tr:eq(1)').remove();
                cnt--;
            }

        }
    });
    
    $('.btnsubmit').click(function (e) {
        var isValid = true;
        $('.drop1,input[type="text"]').each(function () {
            if ($.trim($(this).val()) == '') {
                isValid = false;
                $(this).css({
                    "border": "1px solid red",
                    
                });
    
            }
            else {
                $(this).css({
                    "border": "",
                    "background": ""
                });
            }
        });
        if (isValid == false)
            e.preventDefault();
        else
            alert('Thank you for submitting');
    });
    $(".rate1").click(function () {
        var date1 = $(".pick1").val();
        var date2 = $(".pick").val();
        var d1 = new Date(date1);
        var d2 = new Date(date2);
        if (d1 > d2)
            alert('Please give correct date');
    });
 
});

